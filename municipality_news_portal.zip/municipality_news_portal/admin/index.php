<?php
// admin/index.php - Admin Dashboard & CMS Manager
session_start();
require_once __DIR__ . '/../config/db.php';
$pdo = getDBConnection();

$loginError = '';

// Handle Admin Login
if (isset($_POST['login'])) {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    $stmt = $pdo->prepare("SELECT * FROM admins WHERE username = ?");
    $stmt->execute([$username]);
    $admin = $stmt->fetch();

    if ($admin && password_verify($password, $admin['password'])) {
        $_SESSION['admin_logged_in'] = true;
        $_SESSION['admin_user'] = $admin['full_name'];
        header('Location: index.php');
        exit;
    } else {
        $loginError = 'प्रयोगकर्ताको नाम वा पासवर्ड मिलेन!';
    }
}

// Handle Logout
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: index.php');
    exit;
}

$isLoggedIn = isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;

if ($isLoggedIn) {
    // Fetch all news
    $newsStmt = $pdo->query("SELECT n.*, c.name_np as category_name FROM news n JOIN categories c ON n.category_id = c.id ORDER BY n.created_at DESC");
    $allNews = $newsStmt->fetchAll();

    // Fetch categories
    $catStmt = $pdo->query("SELECT * FROM categories ORDER BY id ASC");
    $categories = $catStmt->fetchAll();

    // Fetch citizen tips
    $tipsStmt = $pdo->query("SELECT * FROM tips ORDER BY created_at DESC");
    $allTips = $tipsStmt->fetchAll();
}
?>
<!DOCTYPE html>
<html lang="ne">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>एडमिन प्यानल | नगरिक खबर CMS</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/style.css">
    <link rel="stylesheet" href="css/admin.css">
</head>
<body>

<?php if (!$isLoggedIn): ?>
    <!-- LOGIN VIEW -->
    <div class="login-card">
        <div style="text-align: center; margin-bottom: 24px;">
            <i class="fas fa-user-shield fa-3x" style="color:var(--primary-red);"></i>
            <h2 style="color:var(--navy-blue); margin-top:10px;">नगरपालिका CMS एडमिन लगइन</h2>
        </div>

        <?php if ($loginError): ?>
            <div style="background:#FEE2E2; color:#991B1B; padding:10px; border-radius:6px; margin-bottom:16px; font-size:0.9rem;">
                <i class="fas fa-exclamation-circle"></i> <?= $loginError ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="index.php">
            <div class="form-group">
                <label>प्रयोगकर्ताको नाम (Username)</label>
                <input type="text" name="username" class="form-control" required placeholder="admin">
            </div>
            <div class="form-group">
                <label>पासवर्ड (Password)</label>
                <input type="password" name="password" class="form-control" required placeholder="admin123">
            </div>
            <button type="submit" name="login" class="btn-primary" style="margin-top:10px;">
                <i class="fas fa-sign-in-alt"></i> लगइन गर्नुहोस्
            </button>
        </form>
        <p style="font-size:0.8rem; color:var(--text-muted); margin-top:16px; text-align:center;">
            (Default: admin / admin123)
        </p>
    </div>

<?php else: ?>

    <!-- ADMIN DASHBOARD VIEW -->
    <div class="admin-header">
        <h1><i class="fas fa-tachometer-alt"></i> नगरिक खबर - प्रशासकीय CMS प्यानल</h1>
        <div style="display:flex; align-items:center; gap:16px;">
            <span><i class="fas fa-user-circle"></i> स्वागतम्, <?= htmlspecialchars($_SESSION['admin_user']) ?></span>
            <a href="../index.php" target="_blank" style="color:#FFF; background:rgba(255,255,255,0.15); padding:6px 12px; border-radius:4px; font-size:0.85rem;"><i class="fas fa-globe"></i> मुख्य साइट</a>
            <a href="index.php?logout=1" style="color:#FFF; background:var(--primary-red); padding:6px 12px; border-radius:4px; font-size:0.85rem;"><i class="fas fa-power-off"></i> लगआउट</a>
        </div>
    </div>

    <div class="admin-container">
        <!-- TOP STATS & ACTIONS -->
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:24px;">
            <h2><i class="fas fa-newspaper"></i> प्रकाशित समाचार तथा सूचनाहरू (<?= count($allNews) ?>)</h2>
            <button class="btn-primary" style="width:auto; padding:10px 20px;" onclick="$('#add-news-modal').css('display','flex');">
                <i class="fas fa-plus-circle"></i> नयाँ समाचार थप्नुहोस्
            </button>
        </div>

        <!-- NEWS MANAGEMENT TABLE -->
        <div class="table-responsive">
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>तस्बिर</th>
                        <th>शीर्षक</th>
                        <th>विधा (Category)</th>
                        <th>हेरिएको</th>
                        <th>स्थिति (Flags)</th>
                        <th>मिति</th>
                        <th>कार्य (Actions)</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (empty($allNews)): ?>
                        <tr><td colspan="8" style="text-align:center;">कुनै समाचार हाल उपलब्ध छैन।</td></tr>
                    <?php else: ?>
                        <?php foreach ($allNews as $n): ?>
                        <tr>
                            <td><?= $n['id'] ?></td>
                            <td><img src="<?= htmlspecialchars($n['image_url']) ?>" style="width:50px; height:40px; object-fit:cover; border-radius:4px;"></td>
                            <td style="font-weight:600; max-width:300px;"><?= htmlspecialchars($n['title_np']) ?></td>
                            <td><span class="badge badge-success"><?= htmlspecialchars($n['category_name']) ?></span></td>
                            <td><?= $n['views'] ?></td>
                            <td>
                                <?= $n['is_featured'] ? '<span class="badge badge-warning">Featured</span> ' : '' ?>
                                <?= $n['is_breaking'] ? '<span class="badge badge-danger">Breaking</span>' : '' ?>
                            </td>
                            <td style="font-size:0.85rem; color:var(--text-muted);"><?= date('Y-m-d', strtotime($n['created_at'])) ?></td>
                            <td>
                                <a href="../article.php?id=<?= $n['id'] ?>" target="_blank" class="btn-sm" style="background:#1D3557; color:#FFF;"><i class="fas fa-eye"></i> हेर्नुहोस्</a>
                                <button onclick="deleteNews(<?= $n['id'] ?>)" class="btn-sm" style="background:#D62828; color:#FFF;"><i class="fas fa-trash"></i> मेट्नुहोस्</button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>

        <!-- CITIZEN TIPS TABLE SECTION -->
        <div style="margin-top: 40px;">
            <h2><i class="fas fa-inbox"></i> नागरिकहरूबाट प्राप्त समाचार तथा सुझावहरू (<?= count($allTips) ?>)</h2>
            <div class="table-responsive">
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>पठाउने व्यक्ति</th>
                            <th>फोन नम्बर</th>
                            <th>विषय / शीर्षक</th>
                            <th>विस्तृत विवरण</th>
                            <th>मिति</th>
                            <th>कार्य</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (empty($allTips)): ?>
                            <tr><td colspan="7" style="text-align:center;">कुनै सुझाव प्राप्त भएको छैन।</td></tr>
                        <?php else: ?>
                            <?php foreach ($allTips as $tip): ?>
                            <tr>
                                <td><?= $tip['id'] ?></td>
                                <td style="font-weight:700;"><?= htmlspecialchars($tip['sender_name']) ?></td>
                                <td><?= htmlspecialchars($tip['sender_phone']) ?></td>
                                <td style="font-weight:600;"><?= htmlspecialchars($tip['tip_title']) ?></td>
                                <td style="max-width:350px; font-size:0.9rem;"><?= htmlspecialchars($tip['tip_details']) ?></td>
                                <td style="font-size:0.85rem;"><?= date('Y-m-d H:i', strtotime($tip['created_at'])) ?></td>
                                <td>
                                    <button onclick="deleteTip(<?= $tip['id'] ?>)" class="btn-sm" style="background:#D62828; color:#FFF;"><i class="fas fa-trash"></i></button>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- ADD NEWS MODAL POPUP -->
    <div class="modal-overlay" id="add-news-modal">
        <div class="modal-content" style="max-width: 750px;">
            <button class="modal-close" onclick="$('#add-news-modal').hide();">&times;</button>
            <h2 style="color:var(--navy-blue); margin-bottom: 20px;"><i class="fas fa-pen-nib"></i> नयाँ समाचार प्रकाशित गर्नुहोस्</h2>

            <form id="create-news-form">
                <input type="hidden" name="action" value="create_news">
                
                <div style="display:grid; grid-template-columns:1fr 1fr; gap:16px;">
                    <div class="form-group">
                        <label>समाचार विधा (Category) *</label>
                        <select name="category_id" class="form-control" required>
                            <?php foreach ($categories as $cat): ?>
                                <option value="<?= $cat['id'] ?>"><?= htmlspecialchars($cat['name_np']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>लेखक / शाखा (Author)</label>
                        <input type="text" name="author" class="form-control" value="नगरपालिका प्रेस शाखा">
                    </div>
                </div>

                <div class="form-group">
                    <label>नेपाली शीर्षक (Title in Nepali) *</label>
                    <input type="text" name="title_np" class="form-control" required placeholder="समाचारको मुख्य शीर्षक">
                </div>

                <div class="form-group">
                    <label>अंग्रेजी शीर्षक (Optional English Title for Slug)</label>
                    <input type="text" name="title_en" class="form-control" placeholder="Optional English Title">
                </div>

                <div class="form-group">
                    <label>तस्बिरको URL (Image URL)</label>
                    <input type="url" name="image_url" class="form-control" placeholder="https://images.unsplash.com/photo-...">
                </div>

                <div class="form-group">
                    <label>समाचारको छोटो सारांश (Summary) *</label>
                    <textarea name="summary_np" rows="2" class="form-control" required placeholder="कार्डमा देखिने छोटो सारांश..."></textarea>
                </div>

                <div class="form-group">
                    <label>पूरा समाचार विवरण (Full Content) *</label>
                    <textarea name="content_np" rows="6" class="form-control" required placeholder="विस्तृत समाचार लेख्नुहोस्..."></textarea>
                </div>

                <div style="display:flex; gap:20px; margin-bottom:20px;">
                    <label style="display:flex; align-items:center; gap:8px; font-weight:600; cursor:pointer;">
                        <input type="checkbox" name="is_featured" value="1"> मुख्य समाचार (Featured)
                    </label>
                    <label style="display:flex; align-items:center; gap:8px; font-weight:600; cursor:pointer; color:var(--primary-red);">
                        <input type="checkbox" name="is_breaking" value="1"> मुख्य सूचना (Breaking Ticker)
                    </label>
                </div>

                <div id="add-news-response" style="margin-bottom:12px;"></div>

                <button type="submit" class="btn-primary">
                    <i class="fas fa-upload"></i> प्रकाशित गर्नुहोस्
                </button>
            </form>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.7.0.min.js"></script>
    <script>
        $('#create-news-form').on('submit', function(e) {
            e.preventDefault();
            const $res = $('#add-news-response');
            $res.html('<div style="color:#F77F00;"><i class="fas fa-spinner fa-spin"></i> प्रकाशित हुँदैछ...</div>');

            $.ajax({
                url: '../api/admin_actions.php',
                type: 'POST',
                data: $(this).serialize(),
                dataType: 'json',
                success: function(res) {
                    if (res.status === 'success') {
                        $res.html('<div style="color:green; font-weight:bold;">' + res.message + '</div>');
                        setTimeout(function() { location.reload(); }, 1200);
                    } else {
                        $res.html('<div style="color:red;">' + res.message + '</div>');
                    }
                }
            });
        });

        function deleteNews(id) {
            if (confirm('के तपाईं यो समाचार मेट्न निश्चित हुनुहुन्छ?')) {
                $.post('../api/admin_actions.php', { action: 'delete_news', id: id }, function(res) {
                    if (res.status === 'success') {
                        location.reload();
                    }
                }, 'json');
            }
        }

        function deleteTip(id) {
            if (confirm('के तपाईं यो सुझाव मेट्न निश्चित हुनुहुन्छ?')) {
                $.post('../api/admin_actions.php', { action: 'delete_tip', id: id }, function(res) {
                    if (res.status === 'success') {
                        location.reload();
                    }
                }, 'json');
            }
        }
    </script>

<?php endif; ?>

</body>
</html>
