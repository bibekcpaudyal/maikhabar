<?php
// api/submit_tip.php - Citizen Tip & Feedback Endpoint

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request method']);
    exit;
}

$senderName = isset($_POST['sender_name']) ? trim($_POST['sender_name']) : '';
$senderPhone = isset($_POST['sender_phone']) ? trim($_POST['sender_phone']) : '';
$tipTitle = isset($_POST['tip_title']) ? trim($_POST['tip_title']) : '';
$tipDetails = isset($_POST['tip_details']) ? trim($_POST['tip_details']) : '';

if (empty($senderName) || empty($senderPhone) || empty($tipTitle) || empty($tipDetails)) {
    echo json_encode(['status' => 'error', 'message' => 'कृपया सबै अनिवार्य फाँटहरू (Fields) भर्नुहोस्।']);
    exit;
}

try {
    $pdo = getDBConnection();
    $stmt = $pdo->prepare("INSERT INTO tips (sender_name, sender_phone, tip_title, tip_details) VALUES (?, ?, ?, ?)");
    $stmt->execute([$senderName, $senderPhone, $tipTitle, $tipDetails]);

    echo json_encode(['status' => 'success', 'message' => 'Tip submitted successfully']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
