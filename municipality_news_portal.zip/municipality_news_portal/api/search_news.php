<?php
// api/search_news.php - Live Search API Endpoint

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';

$pdo = getDBConnection();
$q = isset($_GET['q']) ? trim($_GET['q']) : '';

if (empty($q)) {
    echo json_encode(['status' => 'success', 'data' => []]);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT id, title_np, summary_np, image_url, created_at 
        FROM news 
        WHERE title_np LIKE ? OR summary_np LIKE ? OR content_np LIKE ? 
        ORDER BY created_at DESC 
        LIMIT 10
    ");
    $searchTerm = "%" . $q . "%";
    $stmt->execute([$searchTerm, $searchTerm, $searchTerm]);
    $results = $stmt->fetchAll();

    echo json_encode(['status' => 'success', 'data' => $results], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
