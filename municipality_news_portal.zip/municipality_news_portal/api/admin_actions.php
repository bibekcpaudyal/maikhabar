<?php
// api/admin_actions.php - Admin News CRUD Operations API

header('Content-Type: application/json; charset=utf-8');
session_start();
require_once __DIR__ . '/../config/db.php';

// Verify Admin Session
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    echo json_encode(['status' => 'error', 'message' => 'Unauthorized access. Please login.']);
    exit;
}

$pdo = getDBConnection();
$action = isset($_POST['action']) ? $_POST['action'] : (isset($_GET['action']) ? $_GET['action'] : '');

try {
    if ($action === 'create_news') {
        $categoryId = intval($_POST['category_id']);
        $titleNp = trim($_POST['title_np']);
        $titleEn = trim($_POST['title_en'] ?? '');
        $summaryNp = trim($_POST['summary_np']);
        $contentNp = trim($_POST['content_np']);
        $imageUrl = trim($_POST['image_url'] ?? '');
        $author = trim($_POST['author'] ?? 'नगरपालिका प्रेस शाखा');
        $isFeatured = isset($_POST['is_featured']) ? 1 : 0;
        $isBreaking = isset($_POST['is_breaking']) ? 1 : 0;
        
        $slug = strtolower(trim(preg_replace('/[^A-Za-z0-9-]+/', '-', $titleEn ?: 'news-' . time())));

        if (empty($titleNp) || empty($summaryNp) || empty($contentNp)) {
            echo json_encode(['status' => 'error', 'message' => 'शीर्षक, सारांश र समाचार सामग्री अनिवार्य छन्।']);
            exit;
        }

        // Default placeholder image if empty
        if (empty($imageUrl)) {
            $imageUrl = 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=800';
        }

        $stmt = $pdo->prepare("
            INSERT INTO news (category_id, title_np, title_en, slug, summary_np, content_np, image_url, author, is_featured, is_breaking) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ");
        $stmt->execute([$categoryId, $titleNp, $titleEn, $slug, $summaryNp, $contentNp, $imageUrl, $author, $isFeatured, $isBreaking]);

        echo json_encode(['status' => 'success', 'message' => 'समाचार सफलतापूर्बक प्रकाशित भयो!']);
        exit;
    }

    if ($action === 'delete_news') {
        $id = intval($_POST['id']);
        $stmt = $pdo->prepare("DELETE FROM news WHERE id = ?");
        $stmt->execute([$id]);

        echo json_encode(['status' => 'success', 'message' => 'समाचार मेटाइयो।']);
        exit;
    }

    if ($action === 'delete_tip') {
        $id = intval($_POST['id']);
        $stmt = $pdo->prepare("DELETE FROM tips WHERE id = ?");
        $stmt->execute([$id]);

        echo json_encode(['status' => 'success', 'message' => 'सुझाव मेटाइयो।']);
        exit;
    }

    echo json_encode(['status' => 'error', 'message' => 'Invalid action']);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
