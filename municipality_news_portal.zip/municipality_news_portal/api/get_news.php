<?php
// api/get_news.php - AJAX API endpoint for fetching news

header('Content-Type: application/json; charset=utf-8');
require_once __DIR__ . '/../config/db.php';

$pdo = getDBConnection();

$id = isset($_GET['id']) ? intval($_GET['id']) : 0;
$categoryId = isset($_GET['category_id']) ? $_GET['category_id'] : 'all';
$featured = isset($_GET['featured']) ? intval($_GET['featured']) : 0;
$breaking = isset($_GET['breaking']) ? intval($_GET['breaking']) : 0;

try {
    if ($id > 0) {
        // Increment view count
        $pdo->prepare("UPDATE news SET views = views + 1 WHERE id = ?")->execute([$id]);

        // Fetch single news
        $stmt = $pdo->prepare("
            SELECT n.*, c.name_np as category_name, c.name_en as category_name_en 
            FROM news n 
            JOIN categories c ON n.category_id = c.id 
            WHERE n.id = ?
        ");
        $stmt->execute([$id]);
        $news = $stmt->fetch();

        if ($news) {
            echo json_encode(['status' => 'success', 'data' => $news], JSON_UNESCAPED_UNICODE);
        } else {
            echo json_encode(['status' => 'error', 'message' => 'News not found']);
        }
        exit;
    }

    $sql = "
        SELECT n.*, c.name_np as category_name, c.name_en as category_name_en 
        FROM news n 
        JOIN categories c ON n.category_id = c.id 
        WHERE 1=1
    ";
    $params = [];

    if ($categoryId !== 'all' && is_numeric($categoryId)) {
        $sql .= " AND n.category_id = ?";
        $params[] = intval($categoryId);
    }

    if ($featured === 1) {
        $sql .= " AND n.is_featured = 1";
    }

    if ($breaking === 1) {
        $sql .= " AND n.is_breaking = 1";
    }

    $sql .= " ORDER BY n.created_at DESC LIMIT 20";

    $stmt = $pdo->prepare($sql);
    $stmt->execute($params);
    $newsList = $stmt->fetchAll();

    echo json_encode(['status' => 'success', 'data' => $newsList], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    echo json_encode(['status' => 'error', 'message' => $e->getMessage()]);
}
