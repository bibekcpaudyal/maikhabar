// assets/js/main.js - jQuery & AJAX Dynamic Interaction Engine

$(document).ready(function () {
    let currentCategoryId = 'all';

    // 1. Mobile Menu Toggle
    $('#mobile-nav-toggle').on('click', function () {
        $('.nav-links').toggleClass('show');
    });

    // 2. Font Size Resizer Accessibility
    let fontScale = 1.0;
    $('#font-increase').on('click', function () {
        if (fontScale < 1.3) {
            fontScale += 0.05;
            document.documentElement.style.setProperty('--font-scale', fontScale);
        }
    });

    $('#font-decrease').on('click', function () {
        if (fontScale > 0.85) {
            fontScale -= 0.05;
            document.documentElement.style.setProperty('--font-scale', fontScale);
        }
    });

    $('#font-reset').on('click', function () {
        fontScale = 1.0;
        document.documentElement.style.setProperty('--font-scale', 1.0);
    });

    // 3. Category Tab Filtering via AJAX
    $('.tab-btn').on('click', function () {
        $('.tab-btn').removeClass('active');
        $(this).addClass('active');

        currentCategoryId = $(this).data('category');
        loadNewsCategory(currentCategoryId);
    });

    function loadNewsCategory(catId) {
        const $grid = $('#news-grid');
        $grid.html('<div style="grid-column: 1/-1; text-align:center; padding: 40px;"><i class="fas fa-spinner fa-spin fa-2x" style="color:var(--primary-red);"></i><p style="margin-top:10px;">समाचार लोड हुँदैछ...</p></div>');

        $.ajax({
            url: 'api/get_news.php',
            type: 'GET',
            data: { category_id: catId },
            dataType: 'json',
            success: function (response) {
                if (response.status === 'success' && response.data.length > 0) {
                    renderNewsGrid(response.data);
                } else {
                    $grid.html('<div style="grid-column: 1/-1; text-align:center; padding: 40px; color: var(--text-muted);"><i class="fas fa-newspaper fa-3x"></i><p style="margin-top:10px; font-size:1.1rem;">यस विधामा हाल कुनै समाचार उपलब्ध छैन।</p></div>');
                }
            },
            error: function () {
                $grid.html('<div style="grid-column: 1/-1; text-align:center; padding: 30px; color: var(--primary-red);"><p>समाचार लोड गर्दा समस्या आयो। कृपया पुनः प्रयास गर्नुहोस्।</p></div>');
            }
        });
    }

    function renderNewsGrid(newsList) {
        let html = '';
        newsList.forEach(function (news) {
            html += `
            <div class="news-card">
                <div class="card-img-wrap">
                    <img src="${news.image_url || 'https://images.unsplash.com/photo-1504711434969-e33886168f5c?w=500'}" alt="${news.title_np}">
                    <span class="category-badge">${news.category_name || 'समाचार'}</span>
                </div>
                <div class="card-body">
                    <div class="card-meta">
                        <span><i class="far fa-calendar-alt"></i> ${news.formatted_date || news.created_at}</span>
                        <span><i class="far fa-eye"></i> ${news.views} पटक हेरिएको</span>
                    </div>
                    <h3 class="card-title">
                        <a href="javascript:void(0)" onclick="openNewsModal(${news.id})">${news.title_np}</a>
                    </h3>
                    <p class="card-summary">${news.summary_np}</p>
                    <button class="read-more-btn" onclick="openNewsModal(${news.id})">
                        पूरा पढ्नुहोस् <i class="fas fa-arrow-right"></i>
                    </button>
                </div>
            </div>`;
        });
        $('#news-grid').html(html);
    }

    // 4. Live Search Modal & AJAX Search
    $('#search-modal-trigger, .search-trigger').on('click', function () {
        $('#search-modal').css('display', 'flex');
        $('#search-input').focus();
    });

    $('#close-search-modal').on('click', function () {
        $('#search-modal').hide();
    });

    let searchTimeout = null;
    $('#search-input').on('keyup', function () {
        const query = $(this).val().trim();
        clearTimeout(searchTimeout);

        if (query.length < 2) {
            $('#search-results').html('<p style="color:var(--text-muted); text-align:center; padding:20px;">खोजीका लागि कम्तीमा २ अक्षर टाइप गर्नुहोस्...</p>');
            return;
        }

        searchTimeout = setTimeout(function () {
            $('#search-results').html('<div style="text-align:center; padding:20px;"><i class="fas fa-spinner fa-spin"></i> खोजिँदैछ...</div>');
            $.ajax({
                url: 'api/search_news.php',
                type: 'GET',
                data: { q: query },
                dataType: 'json',
                success: function (res) {
                    if (res.status === 'success' && res.data.length > 0) {
                        let resultHtml = '<div style="display:flex; flex-direction:column; gap:12px;">';
                        res.data.forEach(function (item) {
                            resultHtml += `
                            <div style="background:#F8FAFC; padding:12px; border-radius:8px; display:flex; gap:12px; cursor:pointer;" onclick="openNewsModal(${item.id}); $('#search-modal').hide();">
                                <img src="${item.image_url}" style="width:70px; height:60px; object-fit:cover; border-radius:6px;">
                                <div>
                                    <h4 style="font-size:1rem; color:var(--navy-blue); font-weight:700;">${item.title_np}</h4>
                                    <span style="font-size:0.8rem; color:var(--text-muted);"><i class="far fa-clock"></i> ${item.created_at}</span>
                                </div>
                            </div>`;
                        });
                        resultHtml += '</div>';
                        $('#search-results').html(resultHtml);
                    } else {
                        $('#search-results').html('<p style="text-align:center; padding:20px; color:var(--text-muted);">कुनै नतिजा फेला परेन।</p>');
                    }
                }
            });
        }, 300);
    });

    // 5. Open Detailed Article Modal via AJAX
    window.openNewsModal = function (newsId) {
        $('#news-article-modal').css('display', 'flex');
        $('#modal-body-content').html('<div style="text-align:center; padding:50px;"><i class="fas fa-spinner fa-spin fa-3x" style="color:var(--primary-red);"></i><p style="margin-top:15px;">समाचार विवरण लोड हुँदैछ...</p></div>');

        $.ajax({
            url: 'api/get_news.php',
            type: 'GET',
            data: { id: newsId },
            dataType: 'json',
            success: function (res) {
                if (res.status === 'success' && res.data) {
                    const n = res.data;
                    let articleHtml = `
                    <div class="article-modal-header" style="margin-bottom:20px;">
                        <span class="category-badge" style="position:static; display:inline-block; margin-bottom:10px;">${n.category_name}</span>
                        <h2 style="font-size:1.8rem; line-height:1.3; color:var(--navy-blue); font-weight:800; margin-bottom:12px;">${n.title_np}</h2>
                        <div style="display:flex; flex-wrap:wrap; gap:16px; font-size:0.9rem; color:var(--text-muted); border-bottom:1px solid #E2E8F0; padding-bottom:12px;">
                            <span><i class="fas fa-user"></i> ${n.author}</span>
                            <span><i class="far fa-calendar-alt"></i> ${n.created_at}</span>
                            <span><i class="far fa-eye"></i> ${n.views} पटक हेरिएको</span>
                        </div>
                    </div>
                    ${n.image_url ? `<div style="width:100%; max-height:400px; overflow:hidden; border-radius:12px; margin-bottom:20px;"><img src="${n.image_url}" style="width:100%; height:100%; object-fit:cover;"></div>` : ''}
                    <div style="font-size:1.1rem; line-height:1.8; color:#334155; margin-bottom:24px;">
                        <p style="font-weight:700; font-size:1.15rem; color:var(--navy-blue); margin-bottom:14px;">${n.summary_np}</p>
                        <div>${n.content_np}</div>
                    </div>
                    <div style="display:flex; justify-content:space-between; align-items:center; background:#F1F5F9; padding:12px 18px; border-radius:8px;">
                        <span style="font-weight:700; color:var(--navy-blue);">यो समाचार सेयर गर्नुहोस्:</span>
                        <div style="display:flex; gap:10px;">
                            <a href="https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(window.location.href)}" target="_blank" style="background:#1877F2; color:#FFF; padding:6px 14px; border-radius:4px; font-size:0.85rem;"><i class="fab fa-facebook-f"></i> Facebook</a>
                            <button onclick="window.print()" style="background:var(--navy-blue); color:#FFF; padding:6px 14px; border-radius:4px; font-size:0.85rem;"><i class="fas fa-print"></i> प्रिन्ट गर्नुहोस्</button>
                        </div>
                    </div>`;
                    $('#modal-body-content').html(articleHtml);
                } else {
                    $('#modal-body-content').html('<p style="color:var(--primary-red); text-align:center; padding:30px;">समाचार प्राप्त गर्न सकिएन।</p>');
                }
            }
        });
    };

    $('#close-news-modal').on('click', function () {
        $('#news-article-modal').hide();
    });

    // Close Modals on Overlay Click
    $('.modal-overlay').on('click', function (e) {
        if ($(e.target).hasClass('modal-overlay')) {
            $(this).hide();
        }
    });

    // 6. Citizen Tip AJAX Form Handler
    $('#citizen-tip-form').on('submit', function (e) {
        e.preventDefault();
        const $form = $(this);
        const $msgBox = $('#tip-form-response');

        $msgBox.html('<div style="color:#F77F00;"><i class="fas fa-spinner fa-spin"></i> पेश हुँदैछ...</div>');

        $.ajax({
            url: 'api/submit_tip.php',
            type: 'POST',
            data: $form.serialize(),
            dataType: 'json',
            success: function (res) {
                if (res.status === 'success') {
                    $msgBox.html('<div style="background:#DCFCE7; color:#15803D; padding:12px; border-radius:6px; font-weight:700;"><i class="fas fa-check-circle"></i> धन्यवाद! तपाईंको समाचार/सुझाव सफलतापूर्बक प्राप्त भयो।</div>');
                    $form[0].reset();
                } else {
                    $msgBox.html('<div style="background:#FEE2E2; color:#B91C1C; padding:12px; border-radius:6px;"><i class="fas fa-exclamation-circle"></i> ' + res.message + '</div>');
                }
            },
            error: function () {
                $msgBox.html('<div style="background:#FEE2E2; color:#B91C1C; padding:12px; border-radius:6px;">सब्मिट गर्दा त्रुटि भयो। कृपया पुनः प्रयास गर्नुहोस्।</div>');
            }
        });
    });

    // Initial Load
    loadNewsCategory('all');
});
