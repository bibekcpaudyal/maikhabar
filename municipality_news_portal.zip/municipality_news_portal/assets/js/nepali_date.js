// assets/js/nepali_date.js - Live Nepali Date & Time Formatter

(function () {
    const nepaliMonths = [
        'वैशाख', 'जेठ', 'असार', 'साउन', 'भदौ', 'असोज', 
        'कात्तिक', 'मंसीर', 'पुस', 'माघ', 'फागुन', 'चैत'
    ];

    const nepaliDays = [
        'आइतबार', 'सोमबार', 'मङ्गलबार', 'बुधबार', 'बिहीबार', 'शुक्रबार', 'शनिबार'
    ];

    const nepaliNumbers = ['०', '१', '२', '३', '४', '५', '६', '७', '८', '९'];

    function toNepaliDigits(num) {
        return num.toString().split('').map(char => nepaliNumbers[char] || char).join('');
    }

    function getFormattedNepaliDate() {
        const now = new Date();
        const dayName = nepaliDays[now.getDay()];
        
        // Approximate Bikram Sambat conversion (2081 / 2082 / 2083 standard offset for UI display)
        // 56.7 years difference
        const gYear = now.getFullYear();
        const gMonth = now.getMonth();
        const gDate = now.getDate();

        let bsYear = gYear + 57;
        if (gMonth < 3 || (gMonth === 3 && gDate < 14)) {
            bsYear -= 1;
        }

        // Approximate month indexing for Nepal BS Calendar
        let bsMonthIndex = (gMonth + 8.5) % 12;
        bsMonthIndex = Math.floor(bsMonthIndex);

        const bsMonthName = nepaliMonths[bsMonthIndex];
        const bsDayDigit = toNepaliDigits(gDate);
        const bsYearDigit = toNepaliDigits(bsYear);

        return `${dayName}, ${bsDayDigit} ${bsMonthName} ${bsYearDigit} (BS)`;
    }

    function updateLiveClock() {
        const dateElement = document.getElementById('live-nepali-date');
        if (dateElement) {
            dateElement.textContent = getFormattedNepaliDate();
        }
    }

    document.addEventListener('DOMContentLoaded', () => {
        updateLiveClock();
        setInterval(updateLiveClock, 60000);
    });

    window.toNepaliDigits = toNepaliDigits;
})();
