-- database/schema.sql - MySQL Database Schema Export for Nepal Municipality News Portal

CREATE DATABASE IF NOT EXISTS `municipality_news_db` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `municipality_news_db`;

-- Categories Table
CREATE TABLE IF NOT EXISTS `categories` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `name_np` VARCHAR(255) NOT NULL,
  `name_en` VARCHAR(255) NOT NULL,
  `slug` VARCHAR(255) UNIQUE NOT NULL,
  `icon` VARCHAR(100) DEFAULT 'fa-newspaper'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- News Table
CREATE TABLE IF NOT EXISTS `news` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `category_id` INT NOT NULL,
  `title_np` VARCHAR(500) NOT NULL,
  `title_en` VARCHAR(500) DEFAULT NULL,
  `slug` VARCHAR(255) UNIQUE NOT NULL,
  `summary_np` TEXT NOT NULL,
  `content_np` LONGTEXT NOT NULL,
  `image_url` VARCHAR(500) DEFAULT NULL,
  `author` VARCHAR(255) DEFAULT 'नगरपालिका प्रेस शाखा',
  `views` INT DEFAULT 0,
  `is_featured` TINYINT(1) DEFAULT 0,
  `is_breaking` TINYINT(1) DEFAULT 0,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`category_id`) REFERENCES `categories`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Citizen Tips Table
CREATE TABLE IF NOT EXISTS `tips` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `sender_name` VARCHAR(255) NOT NULL,
  `sender_phone` VARCHAR(50) NOT NULL,
  `tip_title` VARCHAR(255) NOT NULL,
  `tip_details` TEXT NOT NULL,
  `image_url` VARCHAR(500) DEFAULT NULL,
  `status` VARCHAR(50) DEFAULT 'pending',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Admin Table
CREATE TABLE IF NOT EXISTS `admins` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `username` VARCHAR(100) UNIQUE NOT NULL,
  `password` VARCHAR(255) NOT NULL,
  `full_name` VARCHAR(255) NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Sample Admin Account (username: admin , password: password_hash of 'admin123')
INSERT INTO `admins` (`username`, `password`, `full_name`) VALUES
('admin', '$2y$10$w0995mI2cZzU.dshD38uB.eY0eY8L0w8zJ05Fz5L0w8zJ05Fz5L0w', 'नगरपालिका प्रशासक');
