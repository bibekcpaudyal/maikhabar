<?php
// database/db_init.php - Database schema creator and sample data seeder

function initializeDatabase($pdo) {
    // 1. Create Categories Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS categories (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name_np TEXT NOT NULL,
        name_en TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        icon TEXT DEFAULT 'fa-newspaper'
    )");

    // 2. Create News / Articles Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS news (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        category_id INTEGER NOT NULL,
        title_np TEXT NOT NULL,
        title_en TEXT,
        slug TEXT UNIQUE NOT NULL,
        summary_np TEXT NOT NULL,
        content_np TEXT NOT NULL,
        image_url TEXT,
        author TEXT DEFAULT 'नगरपालिका प्रेस शाखा',
        views INTEGER DEFAULT 0,
        is_featured INTEGER DEFAULT 0,
        is_breaking INTEGER DEFAULT 0,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (category_id) REFERENCES categories(id)
    )");

    // 3. Create Citizen Tips & Feedback Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS tips (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sender_name TEXT NOT NULL,
        sender_phone TEXT NOT NULL,
        tip_title TEXT NOT NULL,
        tip_details TEXT NOT NULL,
        image_url TEXT,
        status TEXT DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // 4. Create Admin Users Table
    $pdo->exec("CREATE TABLE IF NOT EXISTS admins (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL,
        full_name TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )");

    // Seed Categories
    $categories = [
        ['हालसालैका समाचार', 'Current Affairs', 'current-affairs', 'fa-newspaper'],
        ['सार्वजनिक सूचना', 'Public Notices', 'public-notices', 'fa-bullhorn'],
        ['विकास तथा निर्माण', 'Development Projects', 'development', 'fa-hard-hat'],
        ['वडा समाचार', 'Ward News', 'ward-news', 'fa-map-marked-alt'],
        ['पर्यटन तथा संस्कृति', 'Tourism & Culture', 'tourism-culture', 'fa-monument'],
        ['प्रेस विज्ञप्ति', 'Press Release', 'press-release', 'fa-scroll']
    ];

    $catStmt = $pdo->prepare("INSERT OR IGNORE INTO categories (name_np, name_en, slug, icon) VALUES (?, ?, ?, ?)");
    foreach ($categories as $cat) {
        $catStmt->execute($cat);
    }

    // Seed Admin (Default login: admin / admin123)
    $adminPassword = password_hash('admin123', PASSWORD_DEFAULT);
    $adminStmt = $pdo->prepare("INSERT OR IGNORE INTO admins (username, password, full_name) VALUES (?, ?, ?)");
    $adminStmt->execute(['admin', $adminPassword, 'नगरपालिका प्रशासक (Admin)']);

    // Seed Initial News Data
    $sampleNews = [
        [
            1, // Current Affairs
            'नगरपालिकाद्वारा स्मार्ट सिटी योजनाअन्तर्गत नयाँ चक्रपथ विस्तार कार्यको शिलान्यास',
            'Municipality Lays Foundation for Smart Ring Road Expansion',
            'smart-ringroad-expansion',
            'नगरप्रमुखद्वारा आज आयोजित विशेष समारोहका बीच १० किलोमिटर लामो नगर चक्रपथ विस्तारको शिलान्यास सम्पन्न।',
            'नगरपालिकाको गौरवको आयोजना मानिएको स्मार्ट सिटी चक्रपथ निर्माण कार्य आजदेखि औपचारिक रूपमा सुरु भएको छ। कार्यक्रममा बोल्दै नगरप्रमुखले आगामी १८ महिनाभित्र निर्माण सम्पन्न गरी नगरबासीलाई चुस्त यातायात सुविधा उपलब्ध गराउने प्रतिबद्धता व्यक्त गर्नुभयो। आयोजनामा आधुनिक सडक बत्ती, ढल निकास, साइकल लेन र हरियाली उद्यान समावेश गरिनेछ।',
            'https://images.unsplash.com/photo-1573164713988-8665fc963095?auto=format&fit=crop&w=800&q=80',
            'नगर प्रेस संयोजक',
            1, // Featured
            1  // Breaking
        ],
        [
            2, // Public Notices
            'चालु आर्थिक वर्षको सम्पत्ति कर तथा व्यवसाय कर भुक्तानीसम्बन्धी अति जरुरी सूचना',
            'Important Notice Regarding Property & Business Tax Payment',
            'property-tax-notice-2081',
            'मसान्तभित्र कर भुक्तानी गर्ने नगरबासीहरूलाई १० प्रतिशत विशेष छुटको व्यवस्था गरिएको छ।',
            'सर्वसाधारण नगरबासी तथा व्यवसायीहरूको जानकारीका लागि यो सूचना प्रकाशित गरिएको छ। चालु आर्थिक वर्षको एकीकृत सम्पत्ति कर, भूमी कर तथा व्यवसाय कर आगामी महिनाको मसान्तभित्र बुझाउने सेवाग्राहीलाई कुल कर रकममा १० प्रतिशत छुट दिइनेछ। अनलाइन भुक्तानी प्रणाली (e-Sewa, Khalti, ConnectIPS) मार्फत घरै बसी कर तिर्न सकिने व्यवस्था मिलाइएको छ।',
            'https://images.unsplash.com/photo-1450133064473-71024230f91b?auto=format&fit=crop&w=800&q=80',
            'राजस्व शाखा',
            0,
            1  // Breaking
        ],
        [
            3, // Development
            'वडा नं. ४ मा अत्याधुनिक स्वास्थ्य चौकी भवन निर्माण सम्पन्न, निःशुल्क स्वास्थ्य सेवा सुरु',
            'State-of-the-Art Health Post Building Completed in Ward No. 4',
            'ward4-health-post-completed',
            'आधुनिक प्रयोगशाला, प्रसूति सेवा र २४ घण्टे आपत्कालीन सेवासहितको नयाँ भवन उद्घाटन।',
            'नगरपालिकाको वडा नं. ४ स्थित पिपलडाँडामा रु. २ करोड ५० लाखको लागतमा निर्मित आधुनिक स्वास्थ्य चौकी भवनको आज उद्घाटन गरिएको छ। नयाँ भवनबाट नगरबासीलाई निःशुल्क औषधि वितरण, ल्याब टेस्ट, भिडियो एक्स-रे तथा विशेषज्ञ डाक्टरमार्फत नियमित जाँच सेवा उपलब्ध गराइनेछ।',
            'https://images.unsplash.com/photo-1519494026892-80bbd2d6fd0d?auto=format&fit=crop&w=800&q=80',
            'स्वास्थ्य तथा सामाजिक विकास शाखा',
            1,
            0
        ],
        [
            4, // Ward News
            'वडा नं. ७ मा "जेष्ठ नागरिक तथा अपाङ्गता परिचयपत्र" वितरण शिविर सम्पन्न',
            'Senior Citizen and Disability Card Distribution Completed in Ward 7',
            'ward7-senior-citizen-camp',
            '१५० भन्दा बढी जेष्ठ नागरिक र अपाङ्गता भएका व्यक्तिहरूलाई सामाजिक सुरक्षा परिचयपत्र प्रदान।',
            'वडा कार्यालयको आयोजनामा सञ्चालित एकदिने घुम्ती शिविरमार्फत जेष्ठ नागरिकहरूलाई भत्ता परिचयपत्र र अपाङ्गता भएका नागरिकहरूलाई रातो र नीलो वर्गको परिचयपत्र वितरण गरिएको छ। शिविरमा निःशुल्क स्वास्थ्य परीक्षण र आँखा जाँचसमेत गरिएको थियो।',
            'https://images.unsplash.com/photo-1582213782179-e0d53f98f2ca?auto=format&fit=crop&w=800&q=80',
            'वडा सचिव, वडा नं. ७',
            0,
            0
        ],
        [
            5, // Tourism & Culture
            'ऐतिहासिक गढी तथा सांस्कृतिक क्षेत्रको प्रवर्द्धनका लागि "नगर पर्यटन महोत्सव" आयोजना हुने',
            'Municipal Tourism Festival to Promote Historic Fort & Cultural Heritage',
            'municipal-tourism-festival',
            'नेपाली कला, संस्कृति, मौलिक परिकार र पदयात्रा प्रवर्द्धन गर्ने उद्देश्यले ३ दिने महोत्सव।',
            'हाम्रो नगरपालिकाभित्र रहेका ऐतिहासिककोट, धार्मिक मन्दिर तथा प्राकृतिक दृश्यहरूको प्रवर्द्धनका लागि आउँदो १५ गतेदेखि ३ दिने नगर पर्यटन महोत्सव सञ्चालन हुने भएको छ। महोत्सवमा स्थानीय मौलिक झाँकी, हस्तकला प्रदर्शनी, र परम्परागत नेपाली व्यञ्जनका स्टलहरू रहनेछन्।',
            'https://images.unsplash.com/photo-1544735716-392fe2489ffa?auto=format&fit=crop&w=800&q=80',
            'पर्यटन प्रवर्द्धन समिति',
            1,
            0
        ],
        [
            6, // Press Release
            'फोहरमैला व्यवस्थापन तथा वातावरण संरक्षणसम्बन्धी नगर कार्यपालिकाको प्रेस विज्ञप्ति',
            'Press Release on Waste Management & Environmental Protection',
            'press-release-waste-management',
            'स्रोतमा नै फोहर वर्गीकरण नगर्ने घरधुरीलाई जरिवाना गरिने, कुहिने र नकुहिने फोहर फरक दिन उठाइने।',
            'नगरपालिकालाई स्वच्छ, हरियाली र प्रदुषणमुक्त बनाउने अभियानअन्तर्गत आगामी सातादेखि सबै वडामा "स्रोतमा नै फोहर वर्गीकरण" अनिवार्य गरिएको छ। कुहिने फोहरलाई प्राङ्गारिक मल बनाउन र नकुहिने फोहर पुनःप्रयोगका लागि संकलन गरिनेछ। यस अभियानमा सहयोग पुऱ्याउन सम्पूर्ण नगरबासीहरूमा हार्दिक अपिल गरिन्छ।',
            'https://images.unsplash.com/photo-1532996122724-e3c354a0b15b?auto=format&fit=crop&w=800&q=80',
            'प्रमुख प्रशासकीय अधिकृत',
            0,
            0
        ]
    ];

    $newsStmt = $pdo->prepare("INSERT OR IGNORE INTO news (category_id, title_np, title_en, slug, summary_np, content_np, image_url, author, is_featured, is_breaking) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    foreach ($sampleNews as $n) {
        $newsStmt->execute($n);
    }
}
