<?php
// config/db.php - Database Connection Configuration (SQLite PDO default / MySQL ready)

define('DB_TYPE', 'sqlite'); // Options: 'sqlite' or 'mysql'

// SQLite Path
define('SQLITE_FILE', __DIR__ . '/../database/municipality_news.sqlite');

// MySQL Configuration (if DB_TYPE is set to 'mysql')
define('DB_HOST', 'localhost');
define('DB_NAME', 'municipality_news_db');
define('DB_USER', 'root');
define('DB_PASS', '');

function getDBConnection() {
    try {
        if (DB_TYPE === 'sqlite') {
            $dbDir = dirname(SQLITE_FILE);
            if (!file_exists($dbDir)) {
                mkdir($dbDir, 0777, true);
            }
            
            $firstTime = !file_exists(SQLITE_FILE);
            $pdo = new PDO("sqlite:" . SQLITE_FILE);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

            if ($firstTime) {
                require_once __DIR__ . '/../database/db_init.php';
                initializeDatabase($pdo);
            }
            return $pdo;
        } else {
            $dsn = "mysql:host=" . DB_HOST . ";dbname=" . DB_NAME . ";charset=utf8mb4";
            $pdo = new PDO($dsn, DB_USER, DB_PASS);
            $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
            return $pdo;
        }
    } catch (PDOException $e) {
        die("Database Connection Error: " . $e->getMessage());
    }
}
